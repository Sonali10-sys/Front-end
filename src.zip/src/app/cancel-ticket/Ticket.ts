
export class Ticket{
    ticketId:number=0;
    passengerName:string|undefined;
    passengerAge:string|undefined;
    busId:number|undefined;
    journeyDate:string="";
    bookingDate:string="";
    seatNumber:number|undefined;
    ticketPrice:number=0;
    status:string|undefined;
}