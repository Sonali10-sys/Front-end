import { formatDate } from '@angular/common';
import { Component, Inject, LOCALE_ID, OnInit } from '@angular/core';
import { BusService } from '../bus.service';
import { Ticket } from './Ticket';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {
  bookingDate:string [] = [];
  currentDate:string [] = [];
  curr:string="";
  diff:number=0;
  refund:number=0;
  ticketObj:Ticket=new Ticket();
  ticketId : number=0;
  status:boolean=false;
  bookingStatus:boolean=false;
  refundStatus:boolean=false;
  constructor(private busService : BusService ,@Inject(LOCALE_ID) private locale: string) { }

  ngOnInit(): void {
  }

  getTicketId(){
    
    this.busService.getticketById(this.ticketId).subscribe(
      (data:Ticket)=>{
        this.ticketObj=data
        this.status=true;
        
        if(this.ticketObj.status==="cancelled"){
          this.bookingStatus = true;
          console.log(this.bookingStatus);
        }
        else{
          this.bookingStatus = false;
        }
        console.log(this.ticketObj);
     },
     (err) => {
      console.log(err);

    }

    
    );
    

  }

  cancelTicket(){
    this.ticketObj.status = "cancelled";
    this.curr = formatDate((new Date()), "yyyy-MM-dd",this.locale);
    this.currentDate = this.curr.split("-");
    this.bookingDate = this.ticketObj.bookingDate.split("-");
    console.log(this.currentDate);
    console.log(this.bookingDate);
    if(Number(this.currentDate[0])===Number(this.bookingDate[0])){
      if(Number(this.currentDate[1])===Number(this.bookingDate[1])){ 
            console.log("m3")
           this.diff=Number(this.currentDate[2])-Number(this.bookingDate[2]);
       }else{
            if(Number(this.currentDate[2])<Number(this.bookingDate[2])){
               console.log("m1");
                  this.diff=(30-Number(this.bookingDate[2]))+(Number(this.currentDate[2]));
                 }else{
                   console.log("m2");
                    this.diff=-1;
                    }
          }
  }else{
       console.log("m4")
       this.diff=-1
  }
    if(this.diff>=1 && this.diff<=10){
      this.refund = this.ticketObj.ticketPrice*0.9;
    }
    else if(this.diff>=11 && this.diff<=20){
      this.refund = this.ticketObj.ticketPrice*0.5;
    }
    else if(this.diff>=21 && this.diff<=30){
      this.refund = this.ticketObj.ticketPrice*0.3;
    }
    else{
      this.refund = 0;
    }
    console.log(this.diff);
    this.busService.cancelTicket(this.ticketObj).subscribe(
    (data:Ticket)=> {
      this.ticketObj = data;
      this.refundStatus=true;
      console.log(this.ticketObj);
    },
    (err) => {
      console.log(err);
    }  
    );
  }

}
